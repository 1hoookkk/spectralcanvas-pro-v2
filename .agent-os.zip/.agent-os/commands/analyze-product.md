# Analyze Product

Analyze your product's codebase and install Agent OS

Refer to the instructions located in this file:
@.agent-os/instructions/core/analyze-product.md
