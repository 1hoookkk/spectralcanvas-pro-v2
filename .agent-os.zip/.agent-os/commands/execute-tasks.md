# Execute Task

Execute the next task.

Refer to the instructions located in this file:
@.agent-os/instructions/core/execute-tasks.md
