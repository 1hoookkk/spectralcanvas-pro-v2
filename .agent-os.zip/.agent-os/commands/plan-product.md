# Plan Product

Plan a new product and install Agent OS in its codebase.

Refer to the instructions located in this file:
@.agent-os/instructions/core/plan-product.md
