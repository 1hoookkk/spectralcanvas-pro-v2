# Create Spec

Create a detailed spec for a new feature with technical specifications and task breakdown

Refer to the instructions located in this file:
@.agent-os/instructions/core/create-spec.md
