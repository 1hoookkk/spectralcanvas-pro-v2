# Create Tasks

Create a tasks list with sub-tasks to execute a feature based on its spec.

Refer to the instructions located in this file:
@.agent-os/instructions/core/create-tasks.md
