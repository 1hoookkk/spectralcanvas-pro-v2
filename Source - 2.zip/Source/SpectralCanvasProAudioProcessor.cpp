#include "SpectralCanvasProAudioProcessor.h"
#include "SpectralCanvasProEditor.h"
#include <chrono>

SpectralCanvasProAudioProcessor::SpectralCanvasProAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", Params::createParameterLayout())
{
}

SpectralCanvasProAudioProcessor::~SpectralCanvasProAudioProcessor()
{
#ifdef PHASE4_EXPERIMENT
    // Remove parameter listeners
    apvts.removeParameterListener(Params::ParameterIDs::useTestFeeder, this);
    apvts.removeParameterListener(Params::ParameterIDs::keyFilterEnabled, this);
    apvts.removeParameterListener(Params::ParameterIDs::oscGain, this);
    apvts.removeParameterListener(Params::ParameterIDs::scaleType, this);
    apvts.removeParameterListener(Params::ParameterIDs::rootNote, this);
#endif
}

void SpectralCanvasProAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    currentBlockSize = samplesPerBlock;
    
    // set initial audio path from current params (message thread)
    setAudioPathFromParams();
    lastPath_ = currentPath_.load(std::memory_order_relaxed);
    
    // Initialize RT-safe sample loader
    sampleLoader.initialize(sampleRate);
    
    // Initialize RT-safe test feeder
    maskTestFeeder.initialize(sampleRate, 257); // NUM_BINS for 512-point FFT
    
    // Initialize RT-safe spectral processing components
    spectralEngine = std::make_unique<SpectralEngine>();
    spectralEngine->initialize(sampleRate, samplesPerBlock);
    
    // Connect SampleLoader to SpectralEngine (RT-safe pointer sharing)
    spectralEngine->setSampleLoader(&sampleLoader);
    
    // Initialize Phase 2-3 validation infrastructure  
    processedSampleCount_.store(0, std::memory_order_relaxed);
    // Store epoch in nanoseconds for unified timebase (per spec)
    epochSteadyNanos_.store(std::chrono::steady_clock::now().time_since_epoch().count(), 
                            std::memory_order_relaxed);
    latencyTracker_.reset();
    
    // Clear any existing data in queues
    spectralDataQueue.clear();
    parameterQueue.clear();
    maskColumnQueue.clear();
    
#ifdef PHASE4_EXPERIMENT
    // Initialize Phase 4 experimental components
    const int fftSize = 512;
    const int numBins = fftSize / 2 + 1;  // 257
    const int channels = getTotalNumOutputChannels();
    
    spectralStub.prepare(sampleRate, fftSize, numBins, channels);
    keyFilter.prepare(fftSize, numBins, sampleRate);
    
    // Initialize with default scale (C major)
    keyFilter.rebuildAsync(0, dsp::ScaleType::Major);
    
    // Set up parameter listeners for Phase 4
    
    // Initialize parameter atomics from APVTS values
    useTestFeeder_.store(apvts.getParameterAsValue(Params::ParameterIDs::useTestFeeder).getValue(), std::memory_order_relaxed);
    keyFilterEnabled_.store(apvts.getParameterAsValue(Params::ParameterIDs::keyFilterEnabled).getValue(), std::memory_order_relaxed);
    oscGain_.store(apvts.getParameterAsValue(Params::ParameterIDs::oscGain).getValue(), std::memory_order_relaxed);
    scaleType_.store(static_cast<int>(apvts.getParameterAsValue(Params::ParameterIDs::scaleType).getValue()), std::memory_order_relaxed);
    rootNote_.store(static_cast<int>(apvts.getParameterAsValue(Params::ParameterIDs::rootNote).getValue()), std::memory_order_relaxed);
    
    // Add parameter listeners for real-time updates
    apvts.addParameterListener(Params::ParameterIDs::useTestFeeder, this);
    apvts.addParameterListener(Params::ParameterIDs::keyFilterEnabled, this);
    apvts.addParameterListener(Params::ParameterIDs::oscGain, this);
    apvts.addParameterListener(Params::ParameterIDs::scaleType, this);
    apvts.addParameterListener(Params::ParameterIDs::rootNote, this);
#endif
}

void SpectralCanvasProAudioProcessor::releaseResources()
{
    if (spectralEngine)
        spectralEngine->reset();
        
    sampleLoader.shutdown();
    maskTestFeeder.reset();
}

// Called from parameter listener / message thread whenever GUI toggles mode
void SpectralCanvasProAudioProcessor::setAudioPathFromParams()
{
#ifdef PHASE4_EXPERIMENT
    const bool useTestFeeder = useTestFeeder_.load(std::memory_order_relaxed);
    AudioPath path = useTestFeeder ? AudioPath::TestFeeder : AudioPath::Phase4Synth;
    currentPath_.store(path, std::memory_order_release);
#else
    currentPath_.store(AudioPath::TestFeeder, std::memory_order_release);
#endif
}

#ifdef PHASE4_EXPERIMENT
void SpectralCanvasProAudioProcessor::rtResetPhase4_() noexcept
{
    spectralStub.reset(); // zero phases/magnitudes; RT-safe
}

void SpectralCanvasProAudioProcessor::rtResetTestFeeder_() noexcept
{
    // Reset test feeder state if needed
    // Static phase will be reset naturally due to scope
}

int SpectralCanvasProAudioProcessor::getActiveBinCount() const noexcept
{
    return spectralStub.getActiveBinCount();
}
#endif

void SpectralCanvasProAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, 
                                                   juce::MidiBuffer& midiMessages) noexcept
{
    juce::ignoreUnused(midiMessages);
    juce::ScopedNoDenormals noDenormals;
    
    const int numSamples = buffer.getNumSamples();
    buffer.clear(); // clear once at the top

    // RT path transition handling
    const auto path = currentPath_.load(std::memory_order_acquire);
    if (path != lastPath_)
    {
#ifdef PHASE4_EXPERIMENT
        if (path == AudioPath::Phase4Synth)   rtResetPhase4_();
        else if (path == AudioPath::TestFeeder) rtResetTestFeeder_();
#endif
        lastPath_ = path;
    }

    // Initialize write detection for this block
    wroteAudioFlag_.store(false, std::memory_order_relaxed);

    // Snapshot only the params needed for the chosen path (no APVTS lookups here)
    const bool keyFilterOn = keyFilterEnabled_.load(std::memory_order_relaxed);
    const float oscGain = oscGain_.load(std::memory_order_relaxed);

    switch (path)
    {
        case AudioPath::Silent:
#ifdef PHASE4_EXPERIMENT
            // Drain queued paint columns so "Drops" stays at 0 in silent mode
            spectralStub.popAllMaskColumnsInto(maskColumnQueue); // discard all data
#endif
            // Nothing is rendered; output remains cleared.
            return;

        case AudioPath::TestFeeder:
        {
#ifdef PHASE4_EXPERIMENT
            // Drain queued paint columns so "Drops" stays at 0 in rollback mode
            spectralStub.popAllMaskColumnsInto(maskColumnQueue); // discard; we don't render with these
#endif
            // *** Render ONLY the test feeder here ***
            static float testPhase = 0.0f;
            const float freq = 440.0f;
            const float incr = juce::MathConstants<float>::twoPi * freq / static_cast<float>(getSampleRate());
            
            for (int n = 0; n < numSamples; ++n)
            {
                testPhase += incr;
                if (testPhase >= juce::MathConstants<float>::twoPi) 
                    testPhase -= juce::MathConstants<float>::twoPi;
                
                const float sample = 0.2f * std::sin(testPhase);
                for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
                    buffer.getWritePointer(ch)[n] = sample;
            }
            
            // TestFeeder always writes (direct tone)
            wroteAudioFlag_.store(true, std::memory_order_relaxed);
            return;
        }

        case AudioPath::Phase4Synth:
        {
#ifdef PHASE4_EXPERIMENT
            // 1) Drain GUI → magnitudes (non-blocking)
            spectralStub.popAllMaskColumnsInto(maskColumnQueue);
            
            // 2) Gate
            if (keyFilterOn) {
                keyFilter.apply(spectralStub.getMagnitudesWritePtr(), 257);
            }
            
            // 3) Render
            spectralStub.process(buffer, oscGain);
            
            // Mark "wrote" only if buffer has anything > ~ -120 dBFS
            const float rms = buffer.getNumChannels() > 0
                ? buffer.getRMSLevel(0, 0, numSamples) : 0.0f;
            if (rms > 1.0e-6f)
                wroteAudioFlag_.store(true, std::memory_order_relaxed);
#endif
            return;
        }
    }
    
#if JUCE_DEBUG
    // Health check: detect silent audio in debug builds
    float rmsLevel = buffer.getRMSLevel(0, 0, numSamples);
    if (rmsLevel < 1e-6f) {
        static int silenceCounter = 0;
        if (++silenceCounter % 480 == 0) {  // Log every 10ms at 48kHz
            const char* pathName = useTestFeeder ? "TestFeeder" : "Phase4";
            juce::Logger::writeToLog(juce::String::formatted("Audio path (%s) producing silence", pathName));
        }
    }
#endif
}

// Minimal fallback beep generator (RT-safe)
void SpectralCanvasProAudioProcessor::fallbackBeep(juce::AudioBuffer<float>& buffer) noexcept
{
    static float ph = 0.0f;
    const float inc = float(2.0 * juce::MathConstants<double>::pi * 220.0 / getSampleRate());
    const int ns = buffer.getNumSamples();
    for (int n = 0; n < ns; ++n) {
        ph += inc; 
        if (ph > juce::MathConstants<float>::twoPi) 
            ph -= juce::MathConstants<float>::twoPi;
        const float s = 0.02f * std::sin(ph);
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            buffer.getWritePointer(ch)[n] += s;
    }
}

// Safety fallback audio generator (RT-safe)
void SpectralCanvasProAudioProcessor::generateFallbackBeep(juce::AudioBuffer<float>& buffer, int numSamples) noexcept
{
    static float phase = 0.0f;
    const float frequency = 220.0f; // A3 note
    const float phaseIncrement = frequency * 2.0f * juce::MathConstants<float>::pi / static_cast<float>(currentSampleRate);
    const float amplitude = 0.1f; // Moderate volume
    
    for (int sample = 0; sample < numSamples; ++sample)
    {
        const float sampleValue = std::sin(phase) * amplitude;
        
        // Write to all output channels
        for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
        {
            buffer.setSample(channel, sample, sampleValue);
        }
        
        phase += phaseIncrement;
        if (phase >= 2.0f * juce::MathConstants<float>::pi)
            phase -= 2.0f * juce::MathConstants<float>::pi;
    }
}

#ifdef PHASE4_EXPERIMENT
void SpectralCanvasProAudioProcessor::parameterChanged(const juce::String& parameterID, float newValue)
{
    if (parameterID == Params::ParameterIDs::useTestFeeder)
    {
        useTestFeeder_.store(newValue > 0.5f, std::memory_order_relaxed);
        setAudioPathFromParams(); // Update path atomically
    }
    else if (parameterID == Params::ParameterIDs::keyFilterEnabled)
    {
        keyFilterEnabled_.store(newValue > 0.5f, std::memory_order_relaxed);
    }
    else if (parameterID == Params::ParameterIDs::oscGain)
    {
        oscGain_.store(newValue, std::memory_order_relaxed);
    }
    else if (parameterID == Params::ParameterIDs::scaleType)
    {
        const int scaleType = static_cast<int>(newValue);
        scaleType_.store(scaleType, std::memory_order_relaxed);
        
        // Rebuild key filter LUT with new scale
        const int root = rootNote_.load(std::memory_order_relaxed);
        dsp::ScaleType scale = static_cast<dsp::ScaleType>(scaleType);
        keyFilter.rebuildAsync(root, scale);
    }
    else if (parameterID == Params::ParameterIDs::rootNote)
    {
        const int rootNote = static_cast<int>(newValue);
        rootNote_.store(rootNote, std::memory_order_relaxed);
        
        // Rebuild key filter LUT with new root
        const int scaleType = scaleType_.load(std::memory_order_relaxed);
        dsp::ScaleType scale = static_cast<dsp::ScaleType>(scaleType);
        keyFilter.rebuildAsync(rootNote, scale);
    }
}
#else
void SpectralCanvasProAudioProcessor::parameterChanged(const juce::String&, float)
{
    // No-op when Phase 4 is disabled
}
#endif

juce::AudioProcessorEditor* SpectralCanvasProAudioProcessor::createEditor()
{
    return new SpectralCanvasProEditor(*this);
}

void SpectralCanvasProAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void SpectralCanvasProAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    
    if (xmlState.get() != nullptr && xmlState->hasTagName(apvts.state.getType()))
    {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

bool SpectralCanvasProAudioProcessor::loadSampleFile(const juce::File& audioFile)
{
    // This is called from UI thread - safe to allocate
    return sampleLoader.loadSampleFile(audioFile);
}

void SpectralCanvasProAudioProcessor::generateImmediateAudioFeedback()
{
    // Start diagonal sweep test pattern for paint-to-audio validation
    maskTestFeeder.startDiagonalSweep();
}

// Phase 2-3 getter methods for debug overlay
int SpectralCanvasProAudioProcessor::getBlockSize() const
{
    return currentBlockSize;
}

double SpectralCanvasProAudioProcessor::getSampleRate() const
{
    return currentSampleRate;
}

SpectralCanvasProAudioProcessor::PerformanceMetrics SpectralCanvasProAudioProcessor::getPerformanceMetrics() const
{
    PerformanceMetrics metrics;
    
    // Latency statistics from RT-safe tracker
    metrics.medianLatencyMs = latencyTracker_.getMedianLatencyMs();
    metrics.p95LatencyMs = latencyTracker_.getP95LatencyMs();
    
    // Queue statistics
    metrics.queueDepth = maskColumnQueue.getApproxQueueDepth();
    metrics.dropCount = maskColumnQueue.getDropCount();
    
    // Audio processing stats
    metrics.processedSamples = processedSampleCount_.load(std::memory_order_relaxed);
    
    // TODO: XRun detection from host if available
    metrics.xrunCount = 0;
    
    return metrics;
}

// Plugin factory functions
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SpectralCanvasProAudioProcessor();
}