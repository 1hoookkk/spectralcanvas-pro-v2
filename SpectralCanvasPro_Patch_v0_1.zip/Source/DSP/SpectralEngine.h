#pragma once
#include <JuceHeader.h>
#include "SpscRingBuffer.h"
#include "GestureEvent.h"
#include "TripleMailbox.h"

// ---- UI Spectrogram snapshot sent from audio thread ----
struct SpectralSnapshot
{
    static constexpr int kMaxBins = 2048;
    int numBins = 0;
    float mag[kMaxBins]{}; // power spectrum (linear)
};

// ---- Minimal spectral engine with paint‑to‑audio ----
class SpectralEngine
{
public:
    struct Settings
    {
        int fftOrder = 9;         // 512‑point by default
        int hop = 128;            // 75% overlap at 512 FFT
        float paintDecay = 0.95f; // per‑frame decay of paint energy
        float sampleRate = 44100.0f;
    };

    void initialize (const Settings& s, int maxBlockSize) 
    {
        settings_ = s;
        fftSize_ = 1 << settings_.fftOrder;
        numBins_ = fftSize_/2 + 1;
        jassert (numBins_ <= SpectralSnapshot::kMaxBins);

        fft_ = std::make_unique<juce::dsp::FFT>(settings_.fftOrder);

        window_.setSize (1, fftSize_);
        window_.clear();
        for (int n=0; n<fftSize_; ++n)
            window_.setSample (0, n, 0.5f * (1.0f - std::cos (juce::MathConstants<float>::twoPi * n / (fftSize_-1)))); // Hann

        // Working buffers (no allocations in process)
        timeFifo_.setSize (1, fftSize_);
        fftBuffer_.resize (2 * fftSize_); // interleaved real/imag
        mag_.setSize (1, numBins_);
        phase_.setSize (1, numBins_);
        paintMask_.setSize (1, numBins_);
        ola_.setSize (1, fftSize_ + maxBlockSize + settings_.hop);

        timeFifo_.clear(); fifoWrite_ = 0;
        mag_.clear(); phase_.clear(); paintMask_.clear(); ola_.clear();
    }

    void setGestureQueue (SpscRingBuffer<GestureEvent, 1024>* q) noexcept { gestureQueue_ = q; }
    void setUiMailbox (TripleMailbox<SpectralSnapshot>* mb) noexcept { uiMailbox_ = mb; }

    // Parameters (to be driven by APVTS or manual setters)
    void setBrushGainDb (float db) noexcept { brushGainDb_.store (db); } // positive to boost, negative to cut
    void setDryWet (float wet01) noexcept   { wet01_.store (juce::jlimit (0.0f, 1.0f, wet01)); }

    bool isInitialized() const noexcept { return fft_ != nullptr; }
    int  getNumBins() const noexcept    { return numBins_; }
    int  getFftSize() const noexcept    { return fftSize_; }
    int  getHop() const noexcept        { return settings_.hop; }

    void reset() noexcept
    {
        fifoWrite_ = 0;
        timeFifo_.clear();
        mag_.clear(); phase_.clear(); paintMask_.clear();
        ola_.clear();
    }

    // In‑place processing (mono) — you can call this per channel or on a mix
    void processBlock (float* samples, int numSamples) noexcept
    {
        if (!isInitialized()) return;

        // Consume UI gestures -> build/decay paint mask
        consumeGestures_();

        int pos = 0;
        while (pos < numSamples)
        {
            const int space = fftSize_ - fifoWrite_;
            const int toCopy = juce::jmin (space, numSamples - pos);
            timeFifo_.copyFrom (0, fifoWrite_, samples + pos, toCopy);
            fifoWrite_ += toCopy;
            pos += toCopy;

            if (fifoWrite_ == fftSize_)
            {
                fifoWrite_ = 0;
                // Window
                for (int n=0; n<fftSize_; ++n)
                {
                    const float w = window_.getSample (0, n);
                    const float x = timeFifo_.getSample (0, n) * w;
                    fftBuffer_[2*n]   = x; // real
                    fftBuffer_[2*n+1] = 0; // imag
                }

                // FFT
                fft_->perform (fftBuffer_.data(), fftBuffer_.data(), false);

                // Magnitude/phase
                for (int k=0; k<numBins_; ++k)
                {
                    const float re = fftBuffer_[2*k];
                    const float im = fftBuffer_[2*k+1];
                    const float mag = std::sqrt (re*re + im*im) + 1.0e-12f;
                    const float ph  = std::atan2 (im, re);
                    mag_.setSample (0, k, mag);
                    phase_.setSample (0, k, ph);
                }

                // Apply paint mask (boost or cut)
                const float brushDb  = brushGainDb_.load();
                const float boostLin = juce::Decibels::decibelsToGain (brushDb);
                const float cutLin   = juce::Decibels::decibelsToGain (brushDb); // negative db -> < 1.0

                for (int k=0; k<numBins_; ++k)
                {
                    const float m = mag_.getSample (0, k);
                    const float mask = paintMask_.getSample (0, k); // 0..1
                    float scale = 1.0f;

                    if (brushDb >= 0.0f)
                        scale = 1.0f + (boostLin - 1.0f) * mask; // boost towards boostLin
                    else
                        scale = 1.0f + (cutLin - 1.0f) * mask;     // fade towards cut gain

                    mag_.setSample (0, k, m * scale);
                }

                // Optional: publish snapshot for UI spectrogram
                if (uiMailbox_ != nullptr)
                {
                    auto& w = uiMailbox_->beginWrite();
                    w.numBins = numBins_;
                    for (int k=0; k<numBins_; ++k)
                        w.mag[k] = mag_.getSample (0, k);
                    uiMailbox_->publish();
                }

                // Rebuild complex spectrum
                for (int k=0; k<numBins_; ++k)
                {
                    const float mag = mag_.getSample (0, k);
                    const float ph  = phase_.getSample (0, k);
                    fftBuffer_[2*k]   = mag * std::cos (ph);
                    fftBuffer_[2*k+1] = mag * std::sin (ph);
                }
                // Mirror for real iFFT
                for (int k=numBins_; k<fftSize_; ++k)
                {
                    const int kMirror = fftSize_ - k;
                    fftBuffer_[2*k]   =  fftBuffer_[2*kMirror];
                    fftBuffer_[2*k+1] = -fftBuffer_[2*kMirror+1];
                }

                // iFFT
                fft_->perform (fftBuffer_.data(), fftBuffer_.data(), true);

                // Overlap‑add entire frame at current write head
                for (int n=0; n<fftSize_; ++n)
                {
                    const float y = fftBuffer_[2*n] * (1.0f / fftSize_); // JUCE returns unscaled
                    const int idx = n + olaWritePos_;
                    if (idx < ola_.getNumSamples())
                        ola_.setSample (0, idx, ola_.getSample (0, idx) + y);
                }

                // Advance write head by hop
                olaWritePos_ += settings_.hop;

                // Decay paint mask per spectral frame
                for (int k=0; k<numBins_; ++k)
                    paintMask_.setSample (0, k, paintMask_.getSample (0, k) * settings_.paintDecay);
            }
        }

        // Now mix OLA -> output for this host block, then advance OLA by numSamples
        const float wet = wet01_.load();
        for (int n=0; n<numSamples; ++n)
        {
            const float wetSample = ola_.getSample (0, n);
            samples[n] = (1.0f - wet) * samples[n] + wet * wetSample;
        }

        // Shift OLA left by numSamples and zero tail. Also move write head back.
        const int remaining = ola_.getNumSamples() - numSamples;
        if (remaining > 0)
        {
            for (int n=0; n<remaining; ++n)
                ola_.setSample (0, n, ola_.getSample (0, n + numSamples));
            for (int n=remaining; n<ola_.getNumSamples(); ++n)
                ola_.setSample (0, n, 0.0f);
        }
        olaWritePos_ = juce::jmax (0, olaWritePos_ - numSamples);
    }

private:
    inline float freqFromY01_ (float y01) const noexcept
    {
        // Log mapping: top=Nyquist, bottom=~20 Hz
        const float nyq = settings_.sampleRate * 0.5f;
        const float fMin = 20.0f;
        const float ratio = nyq / fMin;
        return fMin * std::pow (ratio, 1.0f - juce::jlimit (0.0f, 1.0f, y01));
    }

    inline int binFromFreq_ (float f) const noexcept
    {
        const float nyq = settings_.sampleRate * 0.5f;
        const float kf = juce::jlimit (0.0f, 1.0f, f / nyq);
        return juce::jlimit (0, numBins_-1, (int) std::round (kf * (numBins_-1)));
    }

    void stampGaussian_ (int centerBin, float radius01, float amount01) noexcept
    {
        // radius01 ~ fraction of spectrum (log-ish). Convert to bins:
        const float maxRadiusBins = (float) numBins_ * 0.15f; // generous default
        const float sigma = juce::jmax (1.0f, maxRadiusBins * juce::jlimit (0.0f, 1.0f, radius01));
        const int r = (int) std::ceil (sigma * 3.0f);
        for (int k = juce::jmax (0, centerBin - r); k <= juce::jmin (numBins_-1, centerBin + r); ++k)
        {
            const float d = (k - centerBin) / sigma;
            const float g = std::exp (-0.5f * d * d) * amount01; // 0..1
            const float prev = paintMask_.getSample (0, k);
            // Max‑blend ensures quick response and natural decay
            paintMask_.setSample (0, k, juce::jlimit (0.0f, 1.0f, juce::jmax (prev, g)));
        }
    }

    void consumeGestures_() noexcept
    {
        if (gestureQueue_ == nullptr) return;
        GestureEvent ge;
        while (gestureQueue_->pop (ge))
        {
            const float f = freqFromY01_ (ge.y01);
            const int bin = binFromFreq_ (f);
            stampGaussian_ (bin, ge.radius01, ge.intensity01);
        }
    }

    Settings settings_{};
    int fftSize_ = 0;
    int numBins_ = 0;

    std::unique_ptr<juce::dsp::FFT> fft_;
    juce::AudioBuffer<float> window_;
    juce::AudioBuffer<float> timeFifo_;
    std::vector<float> fftBuffer_; // 2*N
    juce::AudioBuffer<float> mag_, phase_;
    juce::AudioBuffer<float> paintMask_;
    juce::AudioBuffer<float> ola_;
    int fifoWrite_ = 0;
    int olaWritePos_ = 0;
    int nHopEmitted_ = 0;

    std::atomic<float> brushGainDb_ { 6.0f };
    std::atomic<float> wet01_       { 1.0f };

    SpscRingBuffer<GestureEvent, 1024>* gestureQueue_ = nullptr;
    TripleMailbox<SpectralSnapshot>* uiMailbox_ = nullptr;
};
