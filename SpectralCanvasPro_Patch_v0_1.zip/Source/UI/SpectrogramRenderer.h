#pragma once
#include <JuceHeader.h>
#include "../DSP/TripleMailbox.h"
#include "../DSP/SpectralEngine.h"

// Simple live spectrogram component that reads spectral snapshots
// from a TripleMailbox and scrolls left.
class SpectrogramRenderer : public juce::Component, private juce::Timer
{
public:
    SpectrogramRenderer() { startTimerHz (30); }

    void setMailbox (TripleMailbox<SpectralSnapshot>* mb) noexcept { mailbox_ = mb; }
    void setLogDisplay (bool shouldLog) noexcept { log_ = shouldLog; }

    void paint (juce::Graphics& g) override
    {
        if (image_.isNull())
        {
            g.fillAll (juce::Colours::black);
            g.setColour (juce::Colours::white.withAlpha (0.5f));
            g.drawFittedText ("Spectrogram", getLocalBounds(), juce::Justification::centred, 1);
            return;
        }
        g.drawImageWithin (image_, 0, 0, getWidth(), getHeight(), juce::RectanglePlacement::stretchToFit);
    }

    void resized() override
    {
        if (getWidth() > 0 && getHeight() > 0)
            image_ = juce::Image (juce::Image::RGB, getWidth(), getHeight(), true);
    }

private:
    void timerCallback() override
    {
        if (mailbox_ == nullptr || image_.isNull())
        {
            repaint();
            return;
        }

        SpectralSnapshot snap;
        mailbox_->read (snap);
        if (snap.numBins <= 0) return;

        // Scroll left by 1 px
        image_.moveImageSection (0, 0, 1, 0, image_.getWidth()-1, image_.getHeight());
        // Draw new column at right
        const int x = image_.getWidth() - 1;
        for (int y = 0; y < image_.getHeight(); ++y)
        {
            // Map y (component space) to bin (spectral)
            const float y01 = 1.0f - (float) y / (float) (image_.getHeight()-1);
            const int k = juce::jlimit (0, snap.numBins-1, (int) std::round (y01 * (snap.numBins-1)));

            float v = snap.mag[k];
            if (log_) v = std::log10 (1.0f + 9.0f * v); // simple log compression 0..1 (assuming mags ~0..1)
            v = juce::jlimit (0.0f, 1.0f, v);
            juce::Colour c = juce::Colour::fromHSV (0.66f - 0.66f * v, 1.0f, v, 1.0f); // purple->cyan
            image_.setPixelAt (x, y, c);
        }

        repaint();
    }

    TripleMailbox<SpectralSnapshot>* mailbox_ = nullptr;
    bool log_ = true;
    juce::Image image_;
};
