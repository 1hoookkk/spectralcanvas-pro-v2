#pragma once
#include <JuceHeader.h>
#include "../DSP/SpscRingBuffer.h"
#include "../DSP/GestureEvent.h"

class CanvasComponent : public juce::Component
{
public:
    explicit CanvasComponent (SpscRingBuffer<GestureEvent, 1024>& q) : queue_ (q)
    {
        setOpaque (true);
    }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (juce::Colours::black);
        g.setColour (juce::Colours::white.withAlpha (0.4f));
        g.drawFittedText ("SpectralCanvas Pro", getLocalBounds(), juce::Justification::centred, 1);
        // simple debug overlay of last Y
        if (hasLast_)
        {
            g.setColour (juce::Colours::yellow.withAlpha (0.5f));
            const int y = (int) std::round (lastY01_ * getHeight());
            g.drawLine (0.0f, (float) y, (float) getWidth(), (float) y, 2.0f);
        }
    }

    void mouseDrag (const juce::MouseEvent& e) override
    {
        const float y01 = juce::jlimit (0.0f, 1.0f, 1.0f - (float) e.position.y / (float) getHeight());
        const auto nowMs = juce::Time::getMillisecondCounter();
        const float dt = juce::jmax (1u, nowMs - lastMs_) * 0.001f;
        const float distance = e.getDistanceFromDragStart();
        // crude speed‑based intensity
        const float speed = distance / juce::jmax (0.001f, dt);
        const float intensity = juce::jlimit (0.0f, 1.0f, speed / 800.0f);

        GestureEvent ge;
        ge.y01 = y01;
        ge.intensity01 = intensity <= 0.0001f ? 0.2f : intensity; // floor to keep visible
        ge.radius01 = brushRadius01_;
        ge.timestampMs = nowMs;

        queue_.push (ge); // if full, event is dropped by design
        lastMs_ = nowMs;
        lastY01_ = y01;
        hasLast_ = true;
        repaint();
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        lastMs_ = juce::Time::getMillisecondCounter();
        mouseDrag (e);
    }

    // Expose a simple setter from parameter attachment
    void setBrushRadius01 (float r) noexcept { brushRadius01_ = juce::jlimit (0.0f, 1.0f, r); }

private:
    SpscRingBuffer<GestureEvent, 1024>& queue_;
    uint32_t lastMs_ = 0;
    float lastY01_ = 0.5f;
    bool hasLast_ = false;
    float brushRadius01_ = 0.08f;
};
